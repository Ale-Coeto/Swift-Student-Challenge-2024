//
//  File.swift
//  
//
//  Created by Alejandra Coeto on 25/02/24.
//

import Foundation
import SwiftUI

enum ARAction {
    case placeHold(type: String)
    case removeAllAnchors
}
