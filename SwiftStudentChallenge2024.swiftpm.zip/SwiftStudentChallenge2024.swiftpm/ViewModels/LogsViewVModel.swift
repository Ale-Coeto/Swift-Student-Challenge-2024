//
//  File.swift
//  
//
//  Created by Alejandra Coeto on 19/02/24.
//

import Foundation

class LogsViewVModel: ObservableObject {
    @Published var addItem: Bool = false
    func delete(item: Log) {
            
    }
    
    init(){}
}
