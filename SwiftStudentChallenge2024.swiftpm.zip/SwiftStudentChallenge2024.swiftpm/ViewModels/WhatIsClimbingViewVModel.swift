//
//  File.swift
//  
//
//  Created by Alejandra Coeto on 24/02/24.
//

import Foundation

class cTypes : Identifiable {
    var title: String
    init(title: String) {
        self.title = title
    }
}


//class WhatIsClimbingViewVModel : ObservableObject {
//    @Published var climbingTypes: [cTypes]
//    let lead = cTypes(title: "Lead climbing")
//    
////    init(){}
//}
