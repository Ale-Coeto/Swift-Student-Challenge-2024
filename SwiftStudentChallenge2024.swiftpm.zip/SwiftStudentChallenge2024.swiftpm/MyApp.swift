//
//  SwiftUIView.swift
//
//
//  Created by Alejandra Coeto on 08/02/24.
//

import SwiftUI

@main
struct MyApp: App {
    let persistence = PersistenceController.preview
        
    
    var body: some Scene {
        
        WindowGroup {
            MainView()
                .environment(\.managedObjectContext, persistence.container.viewContext)
                
        }
    }
}
